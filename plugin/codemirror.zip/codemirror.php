<?php
/*=========================================================
|	This script was developed by alex Roosso.
|	Title: RooCMS Plugin codemirror
|	Author:	alex Roosso
|	Copyright: 2010-2011 (c) alex Roosso. 
|	Web: http://www.black-web.ru
|	All rights reserved.
|----------------------------------------------------------
|	Build date:		0:39 04.03.2011
|	Last Build:		7:12 04.03.2011
|	Version file: 	1.00
=========================================================*/

ob_start("ob_gzhandler", 9);

if(isset($_GET['mode']) && $_GET['mode'] != "" && file_exists("codemirror/mode/".$_GET['mode']."/".$_GET['mode'].".js")) {

$mode = $_GET['mode'];

$out = <<<HTML
	document.write('<link rel="stylesheet" href="plugin/codemirror/lib/codemirror.css">');
	document.write('<script src="plugin/codemirror/lib/codemirror.js"></script>');
	
	document.write('<link rel="stylesheet" href="plugin/codemirror/theme/default.css">');

	document.write('<script src="plugin/codemirror/mode/{$mode}/{$mode}.js"></script>');
HTML;

echo $out;
} 
?>



