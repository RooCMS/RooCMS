export const API_BASE_URL = '/api';
export const APP_NAME = 'RooCMS';
export const DEBUG = false;


